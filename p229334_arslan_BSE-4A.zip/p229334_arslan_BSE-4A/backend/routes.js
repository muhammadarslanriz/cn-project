const express = require('express');
const db = require('./db');
const router = express.Router();

const textFields = ['title', 'description', 'research_area', 'faculty_name', 'department', 'required_skills'];
const allFields = [...textFields, 'available_positions', 'application_deadline', 'status'];

function validate(d) {
  const errors = [];
  for (const f of textFields) {
    if (typeof d[f] !== 'string' || !d[f].trim()) errors.push(`${f} is required`);
  }
  const pos = Number(d.available_positions);
  if (d.available_positions === undefined || d.available_positions === null || d.available_positions === '' || !Number.isInteger(pos) || pos < 1) {
    errors.push('available_positions must be a whole number of at least 1');
  }
  if (typeof d.application_deadline !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(d.application_deadline) || isNaN(new Date(d.application_deadline).getTime())) {
    errors.push('application_deadline must be a valid date (YYYY-MM-DD)');
  }
  if (!['Open', 'Closed'].includes(d.status)) errors.push('status must be Open or Closed');
  return errors;
}

function checkId(req, res, next) {
  if (!/^\d+$/.test(req.params.id)) return res.status(400).json({ error: 'ID must be a positive integer' });
  next();
}

const wrap = fn => (req, res, next) => fn(req, res, next).catch(next);

router.post('/', wrap(async (req, res) => {
  const data = { status: 'Open', ...req.body };
  const errors = validate(data);
  if (errors.length) return res.status(400).json({ error: 'Validation failed', details: errors });
  const [r] = await db.query(
    `INSERT INTO opportunities (title, description, research_area, faculty_name, department, required_skills, available_positions, application_deadline, status)
     VALUES (?,?,?,?,?,?,?,?,?)`,
    [data.title.trim(), data.description.trim(), data.research_area.trim(), data.faculty_name.trim(), data.department.trim(),
     data.required_skills.trim(), Number(data.available_positions), data.application_deadline, data.status]
  );
  const [rows] = await db.query('SELECT * FROM opportunities WHERE id = ?', [r.insertId]);
  res.status(201).json(rows[0]);
}));

router.get('/', wrap(async (req, res) => {
  const [rows] = await db.query('SELECT * FROM opportunities ORDER BY id DESC');
  res.status(200).json(rows);
}));

router.get('/:id', checkId, wrap(async (req, res) => {
  const [rows] = await db.query('SELECT * FROM opportunities WHERE id = ?', [req.params.id]);
  if (!rows.length) return res.status(404).json({ error: 'Opportunity not found' });
  res.status(200).json(rows[0]);
}));

router.put('/:id', checkId, wrap(async (req, res) => {
  const [rows] = await db.query('SELECT * FROM opportunities WHERE id = ?', [req.params.id]);
  if (!rows.length) return res.status(404).json({ error: 'Opportunity not found' });
  const merged = { ...rows[0] };
  for (const f of allFields) if (req.body[f] !== undefined) merged[f] = req.body[f];
  const errors = validate(merged);
  if (errors.length) return res.status(400).json({ error: 'Validation failed', details: errors });
  await db.query(
    `UPDATE opportunities SET title=?, description=?, research_area=?, faculty_name=?, department=?, required_skills=?,
     available_positions=?, application_deadline=?, status=? WHERE id=?`,
    [merged.title.trim(), merged.description.trim(), merged.research_area.trim(), merged.faculty_name.trim(), merged.department.trim(),
     merged.required_skills.trim(), Number(merged.available_positions), merged.application_deadline, merged.status, req.params.id]
  );
  const [updated] = await db.query('SELECT * FROM opportunities WHERE id = ?', [req.params.id]);
  res.status(200).json(updated[0]);
}));

router.delete('/:id', checkId, wrap(async (req, res) => {
  const [r] = await db.query('DELETE FROM opportunities WHERE id = ?', [req.params.id]);
  if (!r.affectedRows) return res.status(404).json({ error: 'Opportunity not found' });
  res.status(200).json({ message: 'Opportunity deleted successfully' });
}));

module.exports = router;
