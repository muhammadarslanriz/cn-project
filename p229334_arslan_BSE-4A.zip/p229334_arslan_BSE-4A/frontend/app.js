const API = '/api/opportunities';
const fields = ['title', 'description', 'research_area', 'faculty_name', 'department', 'required_skills', 'available_positions', 'application_deadline', 'status'];
const formModal = new bootstrap.Modal(document.getElementById('formModal'));
const viewModal = new bootstrap.Modal(document.getElementById('viewModal'));
const form = document.getElementById('oppForm');
const $ = id => document.getElementById(id);

function esc(s) {
  const d = document.createElement('div');
  d.textContent = s ?? '';
  return d.innerHTML;
}

function showAlert(msg, type = 'success') {
  const el = document.createElement('div');
  el.className = `alert alert-${type} alert-dismissible fade show`;
  el.innerHTML = `${esc(msg)}<button type="button" class="btn-close" data-bs-dismiss="alert"></button>`;
  $('alerts').prepend(el);
  setTimeout(() => el.remove(), 5000);
}

async function request(url, options) {
  const res = await fetch(url, { headers: { 'Content-Type': 'application/json' }, ...options });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const detail = data.details ? ': ' + data.details.join(', ') : '';
    throw new Error((data.error || 'Request failed') + detail);
  }
  return data;
}

async function loadAll() {
  try {
    const rows = await request(API);
    $('tbody').innerHTML = rows.length ? rows.map(r => `
      <tr>
        <td>${r.id}</td><td>${esc(r.title)}</td><td>${esc(r.faculty_name)}</td><td>${esc(r.department)}</td>
        <td>${r.available_positions}</td><td>${esc(r.application_deadline)}</td>
        <td><span class="badge bg-${r.status === 'Open' ? 'success' : 'secondary'}">${r.status}</span></td>
        <td class="text-end text-nowrap">
          <button class="btn btn-sm btn-outline-primary" onclick="viewOne(${r.id})">View</button>
          <button class="btn btn-sm btn-outline-secondary" onclick="editOne(${r.id})">Edit</button>
          ${r.status === 'Open' ? `<button class="btn btn-sm btn-outline-warning" onclick="closeOne(${r.id})">Close</button>` : ''}
          <button class="btn btn-sm btn-outline-danger" onclick="deleteOne(${r.id})">Delete</button>
        </td>
      </tr>`).join('') : '<tr><td colspan="8" class="text-center text-muted py-4">No research opportunities found.</td></tr>';
  } catch (e) {
    showAlert(e.message, 'danger');
  }
}

async function viewOne(id) {
  try {
    const r = await request(`${API}/${id}`);
    $('viewBody').innerHTML = `
      <h5>${esc(r.title)} <span class="badge bg-${r.status === 'Open' ? 'success' : 'secondary'}">${r.status}</span></h5>
      <p>${esc(r.description)}</p>
      <dl class="row mb-0">
        <dt class="col-sm-4">ID</dt><dd class="col-sm-8">${r.id}</dd>
        <dt class="col-sm-4">Research Area</dt><dd class="col-sm-8">${esc(r.research_area)}</dd>
        <dt class="col-sm-4">Faculty Member</dt><dd class="col-sm-8">${esc(r.faculty_name)}</dd>
        <dt class="col-sm-4">Department</dt><dd class="col-sm-8">${esc(r.department)}</dd>
        <dt class="col-sm-4">Required Skills</dt><dd class="col-sm-8">${esc(r.required_skills)}</dd>
        <dt class="col-sm-4">Available Positions</dt><dd class="col-sm-8">${r.available_positions}</dd>
        <dt class="col-sm-4">Application Deadline</dt><dd class="col-sm-8">${esc(r.application_deadline)}</dd>
      </dl>`;
    viewModal.show();
  } catch (e) {
    showAlert(e.message, 'danger');
    loadAll();
  }
}

$('addBtn').onclick = () => {
  form.reset();
  form.classList.remove('was-validated');
  $('oppId').value = '';
  $('status').value = 'Open';
  $('formTitle').textContent = 'New Research Opportunity';
  formModal.show();
};

async function editOne(id) {
  try {
    const r = await request(`${API}/${id}`);
    form.classList.remove('was-validated');
    fields.forEach(f => $(f).value = r[f]);
    $('oppId').value = r.id;
    $('formTitle').textContent = `Edit Opportunity #${r.id}`;
    formModal.show();
  } catch (e) {
    showAlert(e.message, 'danger');
    loadAll();
  }
}

form.onsubmit = async e => {
  e.preventDefault();
  form.classList.add('was-validated');
  if (!form.checkValidity()) return;
  const body = {};
  fields.forEach(f => body[f] = $(f).value.trim());
  const id = $('oppId').value;
  try {
    await request(id ? `${API}/${id}` : API, { method: id ? 'PUT' : 'POST', body: JSON.stringify(body) });
    formModal.hide();
    showAlert(id ? 'Opportunity updated successfully.' : 'Opportunity created successfully.');
    loadAll();
  } catch (err) {
    showAlert(err.message, 'danger');
  }
};

async function closeOne(id) {
  try {
    await request(`${API}/${id}`, { method: 'PUT', body: JSON.stringify({ status: 'Closed' }) });
    showAlert('Opportunity closed.');
  } catch (e) {
    showAlert(e.message, 'danger');
  }
  loadAll();
}

async function deleteOne(id) {
  if (!confirm('Delete this opportunity?')) return;
  try {
    await request(`${API}/${id}`, { method: 'DELETE' });
    showAlert('Opportunity deleted.');
  } catch (e) {
    showAlert(e.message, 'danger');
  }
  loadAll();
}

loadAll();
